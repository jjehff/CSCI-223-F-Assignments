// ============================================================================
// File: mthreads02.c (Spring 2024)
// ============================================================================
// This version uses command line arguments to determine how many threads to 
// launch.
// ============================================================================

#include    <stdio.h>
#include    <stdlib.h>
#include    <unistd.h>
#include    <pthread.h>


// function prototypes
void*   ThreadFunc(void  *vptr);

// structure declarations
typedef
struct  ThreadInfo
{
    unsigned long       micros;
    unsigned int        threadNum;

} ThreadInfo;


// ==== main ==================================================================
//
// ============================================================================

int     main(int  argc, char  **argv)
{
    auto    unsigned long       pri_micros;
    auto    unsigned long       sec_micros;
    auto    pthread_t           threadID;
    auto    ThreadInfo          *infoPtr;
    auto    int                 counter;

    // verify the argument count
    ???

    // convert the string argument for the primary thread to an integer
    ???

    // loop and create any remaining secondary threads:
	// -- convert the msecs string argument to an unsigned long
	// -- allocate a ThreadInfo structure
	// -- store the thread ID and microseconds in the structure
	// -- create secondary thread, passing ptr to structure
    ???

    // launch the primary thread loop
    while (1)
        {
        printf("Primary thread at %lu microseconds...\n", pri_micros);
        usleep(pri_micros);
        }

    return 0;

}  // end of "main"



// ==== ThreadFunc ============================================================
// 
// This is the thread function for the secondary thread. The caller provides a
// pointer to a ThreadInfo structure, which contains the thread number and the
// number of microseconds to wait between output messages. Once that information
// is fetched from the structure, an inifinite loop is entered that displays 
// messages that the current secondary thread is executing.
//
// Input:
//     vptr [IN]    -- a void pointer to a ThreadInfo structure
//
// Output:
//     A NULL pointer; this is never actually returned because the loop for the
//     secondary thread is inifinite!
// 
// ============================================================================

void*   ThreadFunc(void  *vptr)
{
    ???

}  // end of "ThreadFunc"
