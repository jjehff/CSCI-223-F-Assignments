// ============================================================================
// File: mthreads01.c (Spring 2024)
// ============================================================================
// This version just works with two threads.
// ============================================================================

#include    <stdio.h>
#include    <stdlib.h>
#include    <unistd.h>
#include    <pthread.h>


// function prototypes
void*   ThreadFunc(void  *vptr);


// ==== main ==================================================================
//
// ============================================================================

int     main(int  argc, char  **argv)
{
    auto    unsigned long       counter = 0;
    auto    unsigned long       primaryMsecs;
    auto    unsigned long       secondMsecs;
    auto    pthread_t           threadID;

    // verify the argument count
    ???

    // convert the string arguments to integers for the primary microseconds
    // and the secondary microseconds
    ???

    // call 'pthread_create' to create the secondary thread, passing the
    // secondary thread's microseconds interval as an argument
    ???

    // launch the primary thread loop
    while (1)
        {
        printf("Primary thread at %lu microseconds, counter = %lu...\n"
                                                    , primaryMsecs, counter);
        usleep(primaryMsecs);
        ++counter;
        }

    return 0;

}  // end of "main"



// ==== ThreadFunc ============================================================
// 
// This is the thread function for the secondary thread. The caller provides a
// pointer to an unsigned long that contains the number of microseconds to
// pause between messages. The value is fetched using the parameter, then an
// inifinite loop is entered that displays messages that the secondary thread
// is executing.
//
// Input:
//     vptr [IN]    -- a void pointer to an unsigned long that contains the
//                     number of microseconds to pause on each loop iteration
//
// Output:
//     A NULL pointer; this is never actually returned because the loop for the
//     secondary thread is inifinite!
// 
// ============================================================================

void*   ThreadFunc(void  *vptr)
{
    ???

}  // end of "ThreadFunc"
